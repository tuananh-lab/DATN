#!/bin/bash

doxygen
