#!/bin/bash

mkdir build -p
cd build
cmake ..
cmake --build .
