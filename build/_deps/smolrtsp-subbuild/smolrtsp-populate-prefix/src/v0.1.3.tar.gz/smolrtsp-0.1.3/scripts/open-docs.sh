#!/bin/bash

xdg-open docs/index.html
